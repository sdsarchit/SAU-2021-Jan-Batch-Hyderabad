export const CustomColors = {
    customGrey: '#808080',
    customyellow: '#FFFF00',
    customBlue: '#0000FF'
}