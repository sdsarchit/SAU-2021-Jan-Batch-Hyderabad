export default Api = {
  tmdbKey: '61f88740f7d9c15f7217b0f2e5dc8620',
  popularMoviesURL: 'https://api.themoviedb.org/3/movie/popular?api_key=',
  topRatedMoviesURL: 'https://api.themoviedb.org/3/movie/top_rated?api_key=',
  upcomingMoviesURL: 'https://api.themoviedb.org/3/movie/upcoming?api_key=',
  imageBaseURL: 'https://image.tmdb.org/t/p/w300/',
  getMovieDetailsBaseURL: 'https://api.themoviedb.org/3/movie/',
};
