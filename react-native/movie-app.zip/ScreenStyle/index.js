export default ScreenStyle = {
  options: {
    headerStyle: {
      backgroundColor: '#89CFF0',
    },
    headerTitleStyle: {
      alignContent: 'flex-start',
      fontSize: 22,
    },
  },
};
