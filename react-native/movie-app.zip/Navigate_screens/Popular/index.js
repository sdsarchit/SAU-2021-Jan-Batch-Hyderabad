import React from 'react';
import ListDisplay from '../../Components/DisplayList';
import {createStackNavigator} from '@react-navigation/stack';
import DetailsPage from '../../Components/MovieDetails';
import Api from '../../Api';
import ScreenStyle from '../../ScreenStyle';

const PopularMovies = ({navigation}) => {
  return <ListDisplay navigation={navigation} baseURL={Api.popularMoviesURL} />;
};

const CardDetailStacks = createStackNavigator();

export default Popular = () => {
  return (
    <CardDetailStacks.Navigator>
      <CardDetailStacks.Screen
        options={ScreenStyle.options}
        name="Popular Movies"
        component={PopularMovies}
      />
      <CardDetailStacks.Screen
        options={ScreenStyle.options}
        name="Movie Details"
        component={DetailsPage}
      />
    </CardDetailStacks.Navigator>
  );
};
