import React from 'react';
import ListDisplay from '../../Components/DisplayList';
import {createStackNavigator} from '@react-navigation/stack';
import DetailsPage from '../../Components/MovieDetails';
import Api from '../../Api';
import ScreenStyle from '../../ScreenStyle';

const Movies = ({navigation}) => {
  return (
    <ListDisplay navigation={navigation} baseURL={Api.topRatedMoviesURL} />
  );
};

const CardDetailStacks = createStackNavigator();

export default TopMovie = () => {
  return (
    <CardDetailStacks.Navigator>
      <CardDetailStacks.Screen
        options={ScreenStyle.options}
        name="Top Rated Movies"
        component={Movies}
      />
      <CardDetailStacks.Screen
        options={ScreenStyle.options}
        name="Movie Details"
        component={DetailsPage}
      />
    </CardDetailStacks.Navigator>
  );
};
