import React from 'react';
import ListDisplay from '../../Components/DisplayList';
import {createStackNavigator} from '@react-navigation/stack';
import DetailsPage from '../../Components/MovieDetails';
import Api from '../../Api';
import ScreenStyle from '../../ScreenStyle';

const Movies = ({navigation}) => {
  return (
    <ListDisplay navigation={navigation} baseURL={Api.upcomingMoviesURL} />
  );
};

const CardDetailStacks = createStackNavigator();

export default UpMovie = () => {
  return (
    <CardDetailStacks.Navigator>
      <CardDetailStacks.Screen
        options={ScreenStyle.options}
        name="Up Coming Movies"
        component={Movies}
      />
      <CardDetailStacks.Screen
        options={ScreenStyle.options}
        name="Movie Details"
        component={DetailsPage}
      />
    </CardDetailStacks.Navigator>
  );
};
