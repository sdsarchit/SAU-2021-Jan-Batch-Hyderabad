/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
} from 'react-native';

import {
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import Header from './Components/Header';
import {NavigationContainer} from '@react-navigation/native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {FontAwesomeIcon} from '@fortawesome/react-native-fontawesome';
import {
  faFire,
  faStar,
  faCalendarCheck,
} from '@fortawesome/free-solid-svg-icons';
import Popular from './Navigate_screens/Popular';
import TopMovie from './Navigate_screens/Top';
import UpMovie from './Navigate_screens/Up';
import styles from './Styles';
import {CustomColors} from './CustomColors';

const Tab = createBottomTabNavigator();

const App = () => {
  return (
    <SafeAreaView style={{flex: 6}}>
      <Header title="The Movie Database" />
      <View style={styles.mainViewArea}>
        <NavigationContainer style={{flex: 1}}>
          <Tab.Navigator
            screenOptions={({route}) => ({
              tabBarIcon: ({focused, color, size}) => {
                let iconName;
                if (route.name === 'Popular') {
                  iconName = faFire;
                } else if (route.name == 'Top-Rated') {
                  iconName = faStar;
                } else {
                  iconName = faCalendarCheck;
                }

                return <FontAwesomeIcon size={24} icon={iconName} />;
              },
            })}
            tabBarOptions={{
              activeTintColor: CustomColors.customyellow,
              inactiveTintColor: CustomColors.customGrey,
              activeBackgroundColor: CustomColors.customyellow,
              tabStyle: {
                backgroundColor: CustomColors.customGrey,
              },
              labelStyle: {
                fontSize: 14,
              },
            }}>
            <Tab.Screen name="Popular" component={Popular} />
            <Tab.Screen name="Top-Rated" component={TopMovie} />
            <Tab.Screen name="Up-Coming" component={UpMovie} />
          </Tab.Navigator>
        </NavigationContainer>
      </View>
    </SafeAreaView>
  );
};

export default App;
