import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-formgenerate',
  templateUrl: './formgenerate.component.html',
  styleUrls: ['./formgenerate.component.css']
})
export class FormgenerateComponent implements OnInit {

  constructor(private build: FormBuilder) { }
  profile = this.build.group({
  name: [''],
  phone: [],
  email: ['']
  });
  result: any;
// tslint:disable-next-line:no-unused-expression
ngOnInit(): void {}
  // tslint:disable-next-line:typedef
  add() {
    this.result = JSON.stringify(this.profile.value);
  }
}
